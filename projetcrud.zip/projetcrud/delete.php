<?php
require_once 'proget.php';
$proget = getproget();
       $id = $_GET['id'];
       deleteproget($id);
       header("Location: index.php");
  

?>