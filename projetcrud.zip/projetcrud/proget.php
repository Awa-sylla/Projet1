<?php
require_once 'config.php';

function getproget(){
    global $pdo;
    $sql = "SELECT * FROM proget";
    //return $pdo->query($sql)->fetchAll(3);
    return $pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC);
}

function genererNumSossier(){
    return "proget".date('Ymdhis')."#";
  }
 
  function addproget($nom, $description, $budjet, $datedebut, $datefin , $statut){
    global $pdo; 
    $numDossier = genererNumSossier();
    $sql = "INSERT INTO proget values (null,'$numDossier',  '$nom', '$description', '$budjet', '$datedebut', '$datefin', '$statut')";
    return $pdo->exec($sql);
}

function getProjetsById($id){
    global $pdo;
    $sql = "SELECT * FROM proget WHERE id = $id";
    return $pdo->query($sql)->fetchAll(2);
}

function updateproget($id, $nom, $description, $budjet, $datedebut, $datefin , $statut){
    global $pdo;
    $sql = "UPDATE proget 
    SET nom = '$nom',
     descriptio = '$description', 
     budjet = '$budjet', 
     datedebut = '$datedebut', 
     datefin = '$datefin', 
     statut = '$statut' 
     WHERE id = $id";
    return $pdo->exec($sql);
}

function deleteproget($id){
    global $pdo;
    $sql = "DELETE FROM proget WHERE id = $id";
    return $pdo->exec($sql);
}

?>